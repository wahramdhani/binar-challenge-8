import React, { Fragment, useState } from "react";
import Regis from "../components/register/registerComponent";

const RegisterPage = () => {
    const dataUser = [
        {
            id: 1,
            email: "admin@mail.com",
            username: "admin123",
            password: "secret",
            experience: 50,
            lvl: 55

        }
    ]

    const [users, setUsers] = useState(dataUser)
    const initialForm = {
        id: null,
        email: "",
        username: "",
        password: ""
    }

    // const [currentUser, setCurrentUser] = useState(initialForm)

    const Register = (user) => {
        user.id = users.length + 1;
        setUsers([...users, user])
    }

    return (
        <Fragment>
            <h3>Register</h3>
            <Regis Register={Register} />
        </Fragment>
    )
}

export default RegisterPage