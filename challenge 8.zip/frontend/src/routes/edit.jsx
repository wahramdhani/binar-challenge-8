import React, {Fragment} from "react";
import EditUser from "../components/editUser/editComponent";

const EditPlayer = () => {
    return (
        <Fragment>
            <h3>Edit Player</h3>
            <EditUser EditPlayer={EditPlayer} />
        </Fragment>
    )
}

export default EditPlayer