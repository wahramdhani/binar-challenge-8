 import { Fragment } from "react";
 import { Outlet, Link } from "react-router-dom";
 import "./navigationStyle.css"


 const Navigation = () => {
     return (
         <Fragment>
            <div className="navigation">
                 <Link className="logo-style" to="/">
                     logo
                 </Link>
             <div className="nav-item">
                <Link className="nav-link" to="/register">
                    Register
                </Link>
                <Link className="nav-link" to="/edit">
                    Edit Player
                </Link>
                <Link className="nav-link" to="/search">
                    Search Player
                </Link>
             </div>
            </div>
            <Outlet />
         </Fragment>
     );
 };

 export default Navigation
