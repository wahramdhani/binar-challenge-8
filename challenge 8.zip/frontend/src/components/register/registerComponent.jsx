import { useState } from "react";
import { Form, Button } from "react-bootstrap"

const Register = (props) => {
    const initialForm = {
        id: null,
        email: "",
        username: "",
        password: ""
    };
    const [user, setUser] = useState(initialForm);

    const handleInputChange = (e) => {
        const { name, value } = e.target;

        setUser({ ...user, [name]: value})
    };

    console.log(user);
    return (
        <Form
        className="register"
        onSubmit={(e) => {
            e.preventDefault();
            if (
                !user.email ||
                !user.username ||
                !user.password
            )

                return;
            
            props.Register(user)
            setUser(initialForm)
        }}
        >
        <Form.Group className="mb-3" controlId="formGroupEmail">
        <Form.Label>Email</Form.Label>
         <Form.Control 
            type="email" 
            placeholder="Enter email"
            name="email"
            value={user.name}
            onChange={handleInputChange}
            />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formGroupUsername">
        <Form.Label>Username</Form.Label>
         <Form.Control 
            type="text" 
            placeholder="Enter username"
            name="username"
            value={user.username}
            onChange={handleInputChange}
            />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formGroupPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control 
        type="password" 
        placeholder="Password" 
        name="password"
        value={user.password}
        onChange={handleInputChange}
        />
        </Form.Group>
        <Button 
        variant="primary"
        type="submit">
            Register
        </Button>
        </Form>
    )
}

export default Register