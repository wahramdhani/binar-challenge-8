import React, { useState, useEffect } from "react"
import { Form, Button} from "react-bootstrap"

const EditUser = (props) => {
    const [user, setUser] = useState(props.currentUser)

    useEffect(() => {
        setUser(props.currentUser)
    }, [props])

    const handleInputChange = (e) => {
        const { name, value } = e.target;

        setUser({...user, [name]: value})
    }
    
    return (
        <Form className="user"
        onSubmit={(e) => {
            e.preventDefault();
            props.updateUser(user.id, user)
        }}
        >
             <Form.Group className="mb-3" controlId="formGroupEmail">
        <Form.Label>Email</Form.Label>
         <Form.Control 
            type="email" 
            placeholder="Enter email"
            name="email"
            value={user.name}
            onChange={handleInputChange}
            />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formGroupUsername">
        <Form.Label>Username</Form.Label>
         <Form.Control 
            type="text" 
            placeholder="Enter username"
            name="username"
            value={user.username}
            onChange={handleInputChange}
            />
        </Form.Group>
        {/* <Form.Group className="mb-3" controlId="formGroupPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control 
        type="password" 
        placeholder="Password" 
        name="password"
        value={user.password}
        onChange={handleInputChange}
        />
        </Form.Group> */}
         <Form.Group className="mb-3" controlId="formGroupExperience">
        <Form.Label>Your experience</Form.Label>
         <Form.Control 
            type="number" 
            placeholder="Enter number of experience"
            name="experience"
            value={user.experience}
            onChange={handleInputChange}
            />
        </Form.Group>
        <Form.Group className="mb-3" controlId="formGroupLvl">
        <Form.Label>Level</Form.Label>
         <Form.Control 
            type="number" 
            placeholder="Enter number of level"
            name="level"
            value={user.level}
            onChange={handleInputChange}
            />
        </Form.Group>
        <Button variant="primary"
        type="submit">
        </Button>
        </Form>
    )
}

export default EditUser