import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Navigation from './components/navigations/navigationComponent';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import RegisterPage from './routes/register';
import EditPlayer from './routes/edit';


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigation />} />
        <Route path="register" element={<RegisterPage />} />
        <Route path="" element={<EditPlayer />} />
      </Routes>
    </BrowserRouter>

    )
  }


export default App;
